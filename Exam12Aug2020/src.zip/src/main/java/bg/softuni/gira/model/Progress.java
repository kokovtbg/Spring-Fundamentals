package bg.softuni.gira.model;

public enum Progress {
    OPEN, IN_PROGRESS, COMPLETED, OTHER
}
