package bg.softuni.gira.model;

public enum ClassificationName {
    BUG, FEATURE, SUPPORT, OTHER
}
