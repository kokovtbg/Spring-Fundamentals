package bg.softuni.gira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
