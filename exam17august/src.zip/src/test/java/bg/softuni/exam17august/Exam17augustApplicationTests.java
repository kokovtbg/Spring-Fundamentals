package bg.softuni.exam17august;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam17augustApplicationTests {

	@Test
	void contextLoads() {
	}

}
