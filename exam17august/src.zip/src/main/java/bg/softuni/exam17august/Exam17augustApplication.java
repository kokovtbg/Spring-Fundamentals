package bg.softuni.exam17august;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam17augustApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exam17augustApplication.class, args);
	}

}
