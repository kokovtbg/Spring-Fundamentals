package bg.softuni.exam17august.model;

public enum MoodEnum {
    HAPPY, SAD, INSPIRED
}
