package bg.softuni.exam25june;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam25juneApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exam25juneApplication.class, args);
	}

}
