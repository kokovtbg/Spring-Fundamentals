package bg.softuni.exam25june.model;

public enum StyleName {
    POP, ROCK, JAZZ
}
