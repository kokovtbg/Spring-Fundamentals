package bg.softuni.exam25june;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam25juneApplicationTests {

	@Test
	void contextLoads() {
	}

}
